import SwiftUI

struct WaterIntakeView: View {
    @State private var waterLogs: [String] = []
    @State private var totalIntake: Double = 0.0
    @State private var dailyGoal: Double = 3300  // Default 3.3L
    @State private var customAmount: String = ""
    @State private var showGoalAchievedAlert = false
    @State private var weeklyIntake: [Double] = Array(repeating: 0.0, count: 7)

    let waterOptions: [(String, Double)] = [("250ml", 250), ("500ml", 500), ("750ml", 750), ("1L", 1000)]
    let columns = [GridItem(.flexible()), GridItem(.flexible())]

    var body: some View {
        ZStack {
            // Background Gradient
            LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.2), Color.white]), startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()

            VStack(spacing: 0) {
                ScrollView {
                    VStack(spacing: 20) {
                        
                        // Title
                        Text("Water Intake Tracker")
                            .font(.system(size: 28, weight: .bold, design: .rounded))
                            .foregroundColor(.primary)
                            .padding(.top)

                        // Goal Input Section
                        HStack(spacing: 10) {
                            Text("Set Your Daily Goal")
                                .font(.headline)
                                .foregroundColor(.black)

                            HStack {
                                TextField("Goal (ml)", text: Binding(
                                    get: { String(format: "%.0f", dailyGoal) },
                                    set: { if let value = Double($0) { dailyGoal = value } }
                                ))
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                                .keyboardType(.numberPad)
                                .frame(width: 100)
                                
                                Text("ml")
                                    .font(.body)
                            }
                        }
                        .padding()
                        .background(Color(.systemGray6))
                        .cornerRadius(12)

                        // Water Intake Progress
                        VStack(spacing: 5) {
                            Text("Daily Goal: \(Int(dailyGoal)) ml")
                                .font(.headline)
                                .foregroundColor(.gray)

                            ProgressView(value: totalIntake, total: dailyGoal)
                                .progressViewStyle(LinearProgressViewStyle(tint: totalIntake >= dailyGoal ? .green : .blue))
                                .frame(height: 10)
                                .padding(.horizontal)

                            Text("\(Int(totalIntake)) ml / \(Int(dailyGoal)) ml")
                                .font(.system(size: 16, weight: .medium))
                                .foregroundColor(.blue)
                        }
                        .padding()
                        .background(Color(.systemGray6))
                        .cornerRadius(12)

                        // Quick Select Intake
                        VStack(alignment: .leading, spacing: 10) {
                            Text("Quick Add")
                                .font(.headline)
                                .padding(.leading)

                            LazyVGrid(columns: columns, spacing: 15) {
                                ForEach(waterOptions, id: \.0) { option in
                                    Button(action: {
                                        addWaterLog(option.0, amount: option.1)
                                    }) {
                                        Text(option.0)
                                            .font(.title3)
                                            .frame(width: 120, height: 50)
                                            .background(Color.blue.opacity(0.8))
                                            .foregroundColor(.white)
                                            .cornerRadius(12)
                                            .shadow(radius: 2)
                                    }
                                }
                            }
                            .padding(.horizontal)
                        }
                        
                        // Custom Input Field
                        VStack {
                            Text("Custom Amount")
                                .font(.headline)
                                .padding(.leading)

                            HStack {
                                TextField("Enter amount (ml)", text: $customAmount)
                                    .textFieldStyle(RoundedBorderTextFieldStyle())
                                    .keyboardType(.numberPad)
                                    .frame(width: 120)

                                Button(action: {
                                    if let amount = Double(customAmount), amount > 0 {
                                        addWaterLog("\(Int(amount))ml", amount: amount)
                                        customAmount = ""
                                    }
                                }) {
                                    Text("Add")
                                        .font(.headline)
                                        .padding(.horizontal, 15)
                                        .padding(.vertical, 8)
                                        .background(Color.green.opacity(0.8))
                                        .foregroundColor(.white)
                                        .cornerRadius(10)
                                        .shadow(radius: 3)
                                }
                            }
                            .padding()
                        }
                        .background(Color(.systemGray6))
                        .cornerRadius(12)

                        // Table View for logged water intake
                        VStack(alignment: .leading) {
                            Text("Today's Log")
                                .font(.headline)
                                .padding(.leading)

                            List {
                                ForEach(waterLogs, id: \.self) { log in
                                    Text(log)
                                        .padding()
                                }
                                .onDelete(perform: deleteLog)
                            }
                            .frame(height: 200)
                            .listStyle(PlainListStyle())
                        }

                        // Weekly Tracker
                        VStack {
                            Text("📊 Weekly Progress")
                                .font(.headline)
                                .padding(.top)

                            HStack {
                                ForEach(weeklyIntake.indices, id: \.self) { day in
                                    VStack {
                                        Text("\(Int(weeklyIntake[day])) ml")
                                            .font(.caption)
                                        Rectangle()
                                            .frame(width: 20, height: CGFloat(weeklyIntake[day] / dailyGoal * 100))
                                            .cornerRadius(5)
                                            .foregroundColor(weeklyIntake[day] >= dailyGoal ? .green : .blue)
                                        Text(dayLabel(for: day))
                                            .font(.caption2)
                                            .foregroundColor(.gray)
                                    }
                                }
                            }
                            .padding()
                        }
                        .frame(height: 200)
                    }
                    .padding(.bottom, 70) // Adds spacing before fixed button
                }

                // Fixed Reset Button at Bottom
                Button(action: resetWaterLogs) {
                    Text("Reset Daily Intake")
                        .font(.headline)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.red.opacity(0.8))
                        .foregroundColor(.white)
                        .cornerRadius(12)
                        .shadow(radius: 3)
                }
                .padding(.horizontal)
                .padding(.bottom, 10)
            }
            .alert(isPresented: $showGoalAchievedAlert) {
                Alert(
                    title: Text("🎉 Goal Achieved!"),
                    message: Text("Good work! Today's water intake goal of \(Int(dailyGoal)) ml has been met. Stay hydrated!"),
                    dismissButton: .default(Text("Awesome!"))
                )
            }
        }
        .navigationTitle("Daily Water Log")
    }

    // Function to add log and update progress
    private func addWaterLog(_ amountText: String, amount: Double) {
        let timeStamp = DateFormatter.localizedString(from: Date(), dateStyle: .short, timeStyle: .short)
        waterLogs.insert("\(amountText) - \(timeStamp)", at: 0)
        totalIntake += amount

        let dayIndex = Calendar.current.component(.weekday, from: Date()) - 1
        weeklyIntake[dayIndex] += amount

        if totalIntake >= dailyGoal {
            showGoalAchievedAlert = true
        }
    }

    private func deleteLog(at offsets: IndexSet) {
        waterLogs.remove(atOffsets: offsets)
    }

    private func resetWaterLogs() {
        waterLogs.removeAll()
        totalIntake = 0
        weeklyIntake = Array(repeating: 0.0, count: 7)
    }

    private func dayLabel(for index: Int) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "EEE"
        return dateFormatter.string(from: Calendar.current.date(byAdding: .day, value: -index, to: Date())!)
    }
}
